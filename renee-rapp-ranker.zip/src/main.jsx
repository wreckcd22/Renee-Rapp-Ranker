import React from 'react'
import ReactDOM from 'react-dom/client'
import ReneeRappRanker from './ReneeRappRanker'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ReneeRappRanker />
  </React.StrictMode>
)
