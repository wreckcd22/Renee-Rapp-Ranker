import { useState } from 'react'

const songs = [
  "Snow Angel",
  "Talk Too Much",
  "Poison Poison",
  "So What Now",
  "The Wedding Song",
  "Pretty Girls",
  "I Wish",
  "Willow",
  "Bruises",
  "Don’t Tell My Mom",
  "Everything to Everyone",
  "In the Kitchen",
  "Colorado",
  "Too Well",
  "Moon",
  "Tummy Hurts",
  "Gemini Moon"
]

export default function ReneeRappRanker() {
  const [options, setOptions] = useState([0, 1]);
  const [scores, setScores] = useState(Array(songs.length).fill(0));
  const [pairs, setPairs] = useState(
    songs.flatMap((_, i) => songs.slice(i + 1).map((_, j) => [i, i + j + 1]))
  );

  const handleChoice = (winner) => {
    const newScores = [...scores];
    newScores[winner]++;
    setScores(newScores);
    setPairs(pairs.slice(1));
    if (pairs.length > 1) {
      setOptions(pairs[1]);
    } else {
      setOptions([]);
    }
  };

  const sortedSongs = songs
    .map((song, i) => ({ song, score: scores[i] }))
    .sort((a, b) => b.score - a.score);

  return (
    <div style={{ textAlign: 'center', marginTop: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Renee Rapp Song Ranker</h1>
      {options.length ? (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem' }}>
          <button onClick={() => handleChoice(options[0])}>{songs[options[0]]}</button>
          <button onClick={() => handleChoice(options[1])}>{songs[options[1]]}</button>
        </div>
      ) : (
        <div>
          <h2>Your Ranking</h2>
          <ol>
            {sortedSongs.map((s, i) => (
              <li key={i}>{s.song}</li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
